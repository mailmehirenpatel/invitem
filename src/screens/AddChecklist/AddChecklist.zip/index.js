// 3rd Part Imports
import React, {
  useCallback,
  useEffect,
  useState,
  useRef,
  createRef,
} from 'react';
import {
  Alert,
  FlatList,
  Image,
  Pressable,
  Text,
  TouchableOpacity,
  View,
} from 'react-native';

// Local Imports
import {useDispatch, useSelector} from 'react-redux';
import {Icons} from '../../assets';
import {CustomNavbar, CustomTextInput} from '../../components';
import {Strings} from '../../config/strings';
import {ToastError, ToastSuccess} from '../../constants/ToastConstants';
import {
  AddCheckListInfoChirps,
  deleteCheckListInfoChirps,
  getCheckListInfoChirps,
  getEventInfoChirps,
} from '../../store/actions/InfoChirpsAction';
import Colors from '../../theme/Colors';
import styles from './styles';
import {string} from 'yup';
import {ScrollView, TextInput} from 'react-native-gesture-handler';

const AddCheckList = ({navigation, route}) => {
  const [checkListTitle, setCheckListTitle] = useState('');
  const [checkListOption, setCheckListOption] = useState('');
  const [checkOptionList, setCheckOptionList] = useState([]);
  const [checkLists, setCheckLists] = useState([]);
  const dispatch = useDispatch();
  const {InfoChirpsId} = route.params || {};
  const {eventObjectData} = useSelector(state => state.event);
  const {EventInfoChirpsData} = useSelector(state => state.infoChirps);
  const [numTextInputs, setNumTextInputs] = useState(0);

  //const [textValue, setTextValue] = useState('');
  //const [numInputs, setNumInputs] = useState(1);
  const refInputs = useRef(new Map());
  const refInputs2 = useRef([]);

  const [arr, setArr] = useState([0]);
  const object = {};

  const addToRefs = el => {
    const ref = createRef();
    ref.current = el;
    refInputs.current?.set(el, ref);
  };

  useEffect(() => {
    //console.log('render checkListOption');
  }, [checkListOption]);

  const AddInput = useCallback(() => {
    // add a new element in our refInputs array
    setArr(arr => (arr.length > 0 ? [...arr, arr[arr.length - 1] + 1] : [1]));
    setCheckOptionList(current => [...current, checkListOption]);
    setCheckListOption('');
    console.log('setCheckOptionList : ' + checkOptionList);
  }, [checkListOption, checkOptionList]);

  const setInputValue = (index, value) => {
    // first, we are storing input value to refInputs array to track them
    const inputs = refInputs2.current;
    inputs[index] = value;
    console.log('index : ' + index);
    console.log('value : ' + value);

    // shallow copy
    const newArray = [...checkOptionList];
    // mutate copy
    newArray[index] = value;
    // set state
    setCheckOptionList(newArray);
    // we are also setting the text value to the input field onChangeText
    setCheckListOption(value);
  };

  const RemoveInput = i => {
    // remove from the array by index value
    console.log(arr);
    console.log(i);
    setArr(oldValues => {
      return oldValues.filter(arr => arr !== i);
    });
    //setArr(([first, ...rest]) => rest);
  };

  const CheckListInfochirpsId = EventInfoChirpsData?.find(
    i => i.name === 'add checklist',
  );

  /**get checklist infochirps data */
  useEffect(() => {
    CheckListInfochirpsId &&
      dispatch(
        getCheckListInfoChirps(
          eventObjectData?.id,
          CheckListInfochirpsId.id,
          result => {
            result && setCheckLists(result);
          },
        ),
      );
    //console.log(checkLists);
  }, [CheckListInfochirpsId, dispatch, eventObjectData?.id]);

  // Add More checklist options functionality.
  const onAddOptionPress = useCallback(() => {
    setCheckOptionList(current => [...current, checkListOption]);
    setCheckListOption('');
  }, [checkListOption]);

  const onSave = useCallback(() => {
    const AddCheckListRequestData = {
      id: 0,
      eventId: eventObjectData.id,
      infoChirpId: InfoChirpsId,
      title: checkListTitle,
      itemJson: checkOptionList,
    };

    console.log(AddCheckListRequestData);
    if (true) {
      if (checkListTitle === '') {
        ToastError(Strings.EmptyChecklistTitle);
      } else if (checkOptionList.length < 1) {
        ToastError(Strings.ChecklistOptionError);
      } else {
        dispatch(
          // Add Checklist Api Call
          AddCheckListInfoChirps(
            AddCheckListRequestData,
            (isSuccess, message) => {
              if (isSuccess) {
                setCheckListTitle('');
                setCheckOptionList([]);
                ToastSuccess(message);
                dispatch(getEventInfoChirps(eventObjectData.id));
                CheckListInfochirpsId &&
                  dispatch(
                    getCheckListInfoChirps(
                      eventObjectData?.id,
                      CheckListInfochirpsId.id,
                      result => {
                        result && setCheckLists(result);
                      },
                    ),
                  );
              } else {
                ToastError(message);
              }
            },
          ),
        );
      }
    }
  }, [
    CheckListInfochirpsId,
    InfoChirpsId,
    checkListTitle,
    checkOptionList,
    dispatch,
    eventObjectData.id,
  ]);

  /** Get All checklist details View with delete functionality */
  const renderCheckLists = useCallback(
    ({item}) => {
      return (
        <View style={styles.renderEventPollMainView}>
          <View style={styles.questionView}>
            <View>
              <View style={styles.votePollListContainer}>
                <Text style={styles.questionText}>{item?.title}</Text>
                <Pressable
                  onPress={() => {
                    Alert.alert(
                      Strings.DeleteCheckListOptionConfirmationPoll,
                      item.title,
                      [
                        {
                          text: Strings.No,
                          onPress: () => console.log('No Pressed'),
                          style: Strings.cancel,
                        },
                        {
                          text: Strings.Yes,
                          onPress: () => {
                            dispatch(
                              deleteCheckListInfoChirps(
                                item.checkListId,
                                (isSuccess, message) => {
                                  if (isSuccess) {
                                    ToastSuccess(message);
                                    dispatch(
                                      getEventInfoChirps(eventObjectData.id),
                                    );
                                    CheckListInfochirpsId &&
                                      dispatch(
                                        getCheckListInfoChirps(
                                          eventObjectData?.id,
                                          CheckListInfochirpsId.id,
                                          result => {
                                            result && setCheckLists(result);
                                          },
                                        ),
                                      );
                                  } else {
                                    ToastError(message);
                                  }
                                },
                              ),
                            );
                          },
                        },
                      ],
                      {cancelable: false},
                    );
                  }}>
                  <Image
                    source={Icons.deleteIcon}
                    style={styles.deleteIconStyle}
                  />
                </Pressable>
              </View>

              <View style={styles.separatorView} />
            </View>
            {item?.items?.map((e, indexx) => {
              return (
                <View style={styles.checkListOptions}>
                  <View style={styles.checkIconContainer}>
                    <Image
                      source={Icons.checkIcon}
                      style={styles.checkIconStyle}
                    />
                  </View>
                  <Text style={styles.optionText} key={indexx}>
                    {e}
                  </Text>
                </View>
              );
            })}
          </View>
        </View>
      );
    },
    [CheckListInfochirpsId, dispatch, eventObjectData.id],
  );

  return (
    <View style={styles.mainContainer}>
      <CustomNavbar
        leftIcon={Icons.backArrowIcon}
        title={Strings.AddCheckList}
        rightText={Strings.Save}
        onRightAction={onSave}
      />

      <View style={styles.contentContainer}>
        <View style={styles.mainView}>
          <View style={styles.voteTitleView}>
            <Text style={styles.titleText}>{Strings.CheckListTitle}</Text>

            <CustomTextInput
              value={checkListTitle}
              onChangeText={val => setCheckListTitle(val)}
              placeholder={Strings.TitleHere}
              inputStyle={styles.textInputStyle}
              containerStyle={styles.textInputContainerStyle}
              autoCapitalize={'words'}
            />
            <View style={styles.seperator} />
          </View>

          <View style={styles.voteOptionView}>
            <View style={styles.voteOptionUpperView}>
              <Text style={styles.titleText}>{Strings.AddCheckList}</Text>
            </View>
            <ScrollView contentContainerStyle={styles.container}>
              {arr.map((val, index) => (
                <View
                  ref={addToRefs}
                  style={{flexDirection: 'row', alignItems: 'center'}}>
                  <TextInput
                    style={styles.optionText}
                    returnKeyType={'done'}
                    value={checkOptionList[index]}
                    onChangeText={value => setInputValue(val, value)}
                    onSubmitEditing={AddInput}
                    placeholder={'option ' + (val + 1)}
                  />
                  {/* To remove the input */}
                  <Pressable
                    onPress={() => RemoveInput(val)}
                    style={{marginLeft: 5}}>
                    <Image
                      source={Icons.deleteIcon}
                      style={styles.deleteIconStyle}
                    />
                  </Pressable>
                </View>
              ))}
              {/*<Pressable style={styles.addOptionTextButton} onPress={AddInput}>
                <Text style={styles.addOptionText}>Add Option</Text>
              </Pressable>*/}
            </ScrollView>
          </View>
        </View>
        {checkLists.length > 0 ? (
          <FlatList
            style={styles.flatListContainer}
            scrollEnabled={true}
            data={checkLists}
            keyExtractor={item => item?.checkListId.toString()}
            renderItem={renderCheckLists}
          />
        ) : null}
      </View>
    </View>
  );
};

export default AddCheckList;
